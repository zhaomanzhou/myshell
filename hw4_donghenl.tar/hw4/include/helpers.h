#ifndef HELPERS_H
#define HELPERS_H

#include "linkedList.h"
#include "shell_util.h"

int comparator(void*, void*);


#endif